<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';

// DB connection
$host     = "localhost";
$username = "root";
$password = "";
$dbname   = "vaishanvi";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// On form submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = $conn->real_escape_string($_POST['name']);
    $mobile  = $conn->real_escape_string($_POST['mobile']);
    $email   = $conn->real_escape_string($_POST['email']);
    $message = $conn->real_escape_string($_POST['message']);

    // Save to DB
    $sql = "INSERT INTO contact_form (name, mobile, email, message, submitted_at) 
            VALUES ('$name', '$mobile', '$email', '$message', NOW())";

    if ($conn->query($sql) === TRUE) {
        // Send email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'dineshslps194207@gmail.com';
            $mail->Password   = 'yhcfaivobtbccjdy';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port       = 465;

            $mail->setFrom('info@eternalspace.in', 'Enquiry Form');
            $mail->addAddress('info@eternalspace.in');

            $mail->isHTML(true);
            $mail->Subject = 'New Enquiry Received';
            $mail->Body = "
                <h3>New Enquiry</h3>
                <p><strong>Name:</strong> $name</p>
                <p><strong>Mobile:</strong> $mobile</p>
                <p><strong>Email:</strong> $email</p>
                <p><strong>Message:</strong><br>$message</p>
            ";
            $mail->AltBody = "Name: $name\nMobile: $mobile\nEmail: $email\nMessage: $message";

            $mail->send();
            $success = true;
        } catch (Exception $e) {
            echo "Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Database Error: " . $conn->error;
    }
}
$conn->close();
?>
<?php if (isset($success) && $success): ?>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Success Modal -->
<div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg rounded-4">
      <div class="modal-header bg-success text-white border-0 rounded-top-4">
        <h5 class="modal-title d-flex align-items-center gap-2" id="successModalLabel">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="white" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM6.97 11.03a.75.75 0 0 0 1.08 0l3.992-3.992a.75.75 0 1 0-1.06-1.06L7.5 9.439 5.53 7.47a.75.75 0 0 0-1.06 1.06l2.5 2.5z"/>
          </svg>
          Message Sent
        </h5>
      </div>
      <div class="modal-body text-center">
        <p class="mb-3 fs-5">Thank you! Your message has been submitted successfully.</p>
        <button type="button" class="btn btn-success px-4" data-bs-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS for modal -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const successModal = new bootstrap.Modal(document.getElementById('successModal'));
  window.onload = function () {
    successModal.show();
  };
</script>
<?php endif; ?>

