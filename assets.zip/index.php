<!DOCTYPE html>
<html lang="en">
    

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <!--====== Required meta tags ======-->
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!--====== Title ======-->
        <title>VaishnaviKrishnaBrindavan</title>
        <!--====== Favicon Icon ======-->
        <link rel="shortcut icon" href="assets/images/vainimge.png" type="image/png">
        <!--====== Default css ======-->
        <link rel="stylesheet" href="assets/css/default.css">
        <!--====== Style css ======-->
        <link rel="stylesheet" href="assets/css/style.css">
        <!--====== Responsive css ======-->
        <link rel="stylesheet" href="assets/css/responsive.css">
       
       
    </head>
    <body >
        <!--====== Start Preloader ======-->
        <div class="preloader">
            <div class="loader">
                <div class="pre-shadow"></div>
                <div class="pre-box"></div>
            </div>
        </div>
        <!--====== End Preloader ======--><!--====== Start Header Section ======-->
<header class="theme-header">
            <!-- header top -->
            
            <!-- header Navigation -->
            <div class="header-navigation">
                <div class="container-fluid">
                    <div class="primary-menu">
                        <div class="site-branding">
                            <a href="#" class="brand-logo"><img src="assets/images/vainimge.png" alt="Site Logo"></a>
                        </div>
                        <div class="nav-menu">
                            <!-- Navbar Close -->
                            <div class="navbar-close"><i class="far fa-times"></i></div>
                            <!-- Nav Search -->
                            <div class="nav-search">
                                <form>
                                    <div class="form_group">
                                        <input type="email" class="form_control" placeholder="Search Here" name="email" required>
                                        <button class="search-btn"><i class="fas fa-search"></i></button>
                                    </div>
                                </form>
                            </div>
                            <!-- Main Menu -->
                            <nav class="main-menu">
                            <ul>
	<li ><a href="#">Home</a></li>
	<li ><a href="#price">Price</a></li>
	<li><a href="#about-location">Location</a></li>
	<li ><a href="#floreplane">Flore Plan</a></li>
		<li ><a href="#gallery-section">Amenities</a></li>
		<!-- <li ><a href="#">Location</a></li> -->
		<li><a href="#contact-section">Contact</a></li>
			
		</ul>
	</li>
	
</ul>                            </nav>
                        </div>
                        <div class="header-right-nav">
                            <ul>
                               
                                <li class="navbar-toggle-btn">
                                    <div class="navbar-toggler">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--====== End Header Section ======-->
<!--====== Start Hero Section ======-->
<!-- <section class="hero-area">
            <div class="hero-wrapper-one hero-slider-one">
                <div class="single-slider bg_cover" style="background-image: url(assets/images/bvnvi.png);">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-lg-8">
                                <div class="hero-content">
                                    <span class="sub-title text-underline" data-animation="fadeInDown" data-delay=".3s">Vaishnavi Krishna Brindavan</span>
                                    <h1 data-animation="fadeInDown" data-delay=".5s">J P Nagar - South Bangalore
                                    Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                                    
                                    <ul class="button" data-animation="fadeInDown" data-delay=".7s"> -->
                                    <!-- <li><a href="about.html" class="main-btn btn-red-dark">download Brochure</a></li> -->
                                    <!-- <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a> -->
                                    <!-- <li><a href="service-details.html" class="main-btn btn-white">explore more</a></li> -->
                                    <!-- </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-slider bg_cover" style="background-image: url(assets/images/bnvani.png);">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="hero-content text-center">
                                    <span class="sub-title text-underline" data-animation="fadeInDown" data-delay=".3s">Vaishnavi Krishna Brindavan</span>
                                    <h1 data-animation="fadeInDown" data-delay=".5s">J P Nagar - South Bangalore
                                    Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                                    <ul class="button" data-animation="fadeInDown" data-delay=".7s"> -->
                                        <!-- <li><a href="about.html" class="main-btn btn-red-dark">download Brochure</a></li> -->
                                        <!-- <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a> -->
                                        <!-- <li><a href="service-details.html" class="main-btn btn-white">explore more</a></li> -->
                                    <!-- </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="single-slider bg_cover" style="background-image: url(assets/images/banvanvi.png);">
                    <div class="container">
                        <div class="row justify-content-end">
                            <div class="col-lg-8">
                                <div class="hero-content text-right">
                                    <span class="sub-title text-underline" data-animation="fadeInDown" data-delay=".3s">Vaishnavi Krishna Brindavan</span>
                                    <h1 data-animation="fadeInDown" data-delay=".5s">J P Nagar - South Bangalore
                                    Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                                    <ul class="button" data-animation="fadeInDown" data-delay=".7s"> -->
                                        <!-- <li><a href="about.html" class="main-btn btn-red-dark">download Brochure</a></li> -->
                                        <!-- <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a> -->
                                        <!-- <li><a href="service-details.html" class="main-btn btn-white">explore more</a></li> -->
                                    <!-- </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section> -->
        <!--====== end Hero Section ======-->
        <!-- new start-->
         <!-- Swiper CSS -->
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />

<section class="hero-area">
    <div class="swiper hero-slider">
        <div class="swiper-wrapper"> -->
            <!-- Slide 1 -->
            <!-- <div class="swiper-slide single-slider bg_cover" style="background-image: url(assets/images/bvnvi.png);">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-lg-8">
                            <div class="hero-content">
                                <span class="sub-title text-underline">Vaishnavi Krishna Brindavan</span>
                                <h1>J P Nagar - South Bangalore Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                                <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- Slide 2 -->
            <!-- <div class="swiper-slide single-slider bg_cover" style="background-image: url(assets/images/bnvani.png);">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8">
                            <div class="hero-content text-center">
                                <span class="sub-title text-underline">Vaishnavi Krishna Brindavan</span>
                                <h1>J P Nagar - South Bangalore Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                                <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- Slide 3 -->
            <!-- <div class="swiper-slide single-slider bg_cover" style="background-image: url(assets/images/banvanvi.png);">
                <div class="container">
                    <div class="row justify-content-end">
                        <div class="col-lg-8">
                            <div class="hero-content text-right">
                                <span class="sub-title text-underline">Vaishnavi Krishna Brindavan</span>
                                <h1>J P Nagar - South Bangalore Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                                <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <!-- Navigation buttons -->
        <!-- <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>
</section> -->

<!-- Swiper JS -->
<!-- <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<script>
    const swiper = new Swiper('.hero-slider', {
        loop: true,
        effect: 'slide',
        direction: 'horizontal',
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
</script> -->

        <!-- end new--><section class="hero-area">
  <div class="hero-wrapper-one hero-slider-one">
    <div class="slider-container">
      <div class="slider-track">
        <!-- Slide 1 -->
        <div class="single-slider bg_cover" style="background-image: url(assets/images/bvnvi.png);">
          <div class="container">
            <div class="row justify-content-start">
              <div class="col-lg-8">
                <div class="hero-content">
                  <span class="sub-title text-underline">Vaishnavi Krishna Brindavan</span>
                  <h1>J P Nagar - South Bangalore<br>Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                  <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Download Brochures</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="single-slider bg_cover" style="background-image: url(assets/images/bnvani.png);">
          <div class="container">
            <div class="row justify-content-center">
              <div class="col-lg-8">
                <div class="hero-content text-center">
                  <span class="sub-title text-underline">Vaishnavi Krishna Brindavan</span>
                  <h1>J P Nagar - South Bangalore<br>Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                  <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Download Brochures</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="single-slider bg_cover" style="background-image: url(assets/images/banvanvi.png);">
          <div class="container">
            <div class="row justify-content-end">
              <div class="col-lg-8">
                <div class="hero-content text-right">
                  <span class="sub-title text-underline">Vaishnavi Krishna Brindavan</span>
                  <h1>J P Nagar - South Bangalore<br>Luxurious 3 & 4 BHK Apartments by Vaishnavi Group</h1>
                  <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Download Brochures</a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>
<style>
.hero-wrapper-one {
  overflow: hidden;
  position: relative;
}

.slider-container {
  width: 100%;
  overflow: hidden;
}

.slider-track {
  display: flex;
  transition: transform 1s ease-in-out;
  animation: slideAnim 15s infinite;
}

.single-slider {
  min-width: 100%;
  height: 120vh;
  background-size: cover;
  background-position: center;
  position: relative;
  display: flex;
  align-items: center;
}

.hero-content {
  color: #fff;
  padding: 2rem;
}

.sub-title {
  display: inline-block;
  font-size: 1.25rem;
  margin-bottom: 1rem;
}

.btn {
  padding: 10px 25px;
  border-radius: 4px;
  display: inline-block;
  margin-top: 1rem;
}

/* Animation Keyframes */
@keyframes slideAnim {
  0% { transform: translateX(0%); }
  33% { transform: translateX(-100%); }
  66% { transform: translateX(-200%); }
  100% { transform: translateX(0%); }
}
</style>


<!--====== popup start Section ======-->



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Popup Form</title>
  <style>
   
    /* Overlay background */
    .popup-overlay {
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }

    /* Popup form box */
    .popup-form {
      background: white;
      padding: 30px;
      border-radius: 10px;
      width: 300px;
      position: relative;
    }

    .popup-form h2 {
      margin-top: 0;
      text-align: center;
    }

    .popup-form input,
    .popup-form textarea {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    .popup-form button {
      background: #007bff;
      color: white;
      border: none;
      padding: 10px;
      width: 100%;
      border-radius: 5px;
      cursor: pointer;
    }

   
  </style>
</head>
<body>

<!-- Popup Form Container -->
<div class="popup-overlay" id="popup">
  <div class="popup-form">
    <button class="close-btn" onclick="closePopup()">×</button>
    <h2>Contact Us</h2>
   <form action="enquire_form.php" method="POST">
  <input type="text" name="name" placeholder="Your Name" required>

  <!-- THIS should be MOBILE -->
  <input type="text" name="mobile" placeholder="Mobile Number" required>

  <!-- THIS should be EMAIL -->
  <input type="email" name="email" placeholder="Email Address" required>

  <textarea name="message" placeholder="Your Message" required></textarea>

  <button type="submit">Submit</button>
</form>

  </div>
</div>

<script>
  // Function to close popup
  function closePopup() {
    document.getElementById('popup').style.display = 'none';
  }

  // Auto open popup when page loads
  window.onload = function() {
    document.getElementById('popup').style.display = 'flex';
  }
</script>

</body>
</html>

<!--======popup end  Section ======-->


<!--====== enquire popup start  Section ======-->

  <style>
    body { font-family: Arial, sans-serif; }

    /* Button styling */
    .btn {
      color: #ffffff;
      background-color: #007bff;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 5px;
      cursor: pointer;
    }

    /* Popup Modal Styles */
    .modal {
      display: none; 
      position: fixed;
      z-index: 1; 
      left: 0; top: 0;
      width: 100%; height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.5); 
    }

    .modal-content {
      background-color: #fefefe;
      margin: 10% auto;
      padding: 20px;
      border-radius: 8px;
      width: 90%;
      max-width: 400px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }

    .close {
      color: #aaa;
      float: right;
      font-size: 24px;
      font-weight: bold;
      cursor: pointer;
    }

    .close:hover { color: black; }

    input, textarea {
      width: 100%;
      padding: 10px;
      margin: 8px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .submit-btn {
      background-color: #007bff;
      color: white;
      border: none;
      padding: 10px;
      width: 100%;
      border-radius: 5px;
      cursor: pointer;
    }

    .submit-btn:hover {
      background-color: #0056b3;
    }
  </style>


<!-- <a href="#" class="btn" onclick="openModal()">Enquire Now</a> -->

<!-- Modal -->
<div id="enquiryModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal()">&times;</span>
    <h3>Enquiry form</h3>
    <form action="enquire_form.php" method="POST">
      <input type="text" name="name" placeholder="Your Name" required>
      <input type="email" name="email" placeholder="Your Email" required>
      <input type="tel" name="mobile" placeholder="Mobile Number" required>
      <textarea rows="4" name="message" placeholder="Your Message" required></textarea>
      <button type="submit" class="submit-btn">Submit</button>
    </form>
  </div>
</div>

<script>
  function openModal() {
    document.getElementById('enquiryModal').style.display = 'block';
  }

  function closeModal() {
    document.getElementById('enquiryModal').style.display = 'none';
  }

  // Close modal if user clicks outside the modal content
  window.onclick = function(event) {
    const modal = document.getElementById('enquiryModal');
    if (event.target === modal) {
      modal.style.display = "none";
    }
  }
</script>



<!--====== enquire popup end  Section ======-->



        <!-- about section start -->
        <section class="about-section">
    <div class="about-container">
      
      <div class="about-content">
        <h2>About Us</h2>
        <p>
        <a  href="#">Vaishnavi Krishna Brindavana</a>
is a newest residential masterpiece apartment that redefines ultra luxury living. Which is being developed by one of the prominent builder Vaishnavi Group. Which is located in J P Nagar, Just 500 M away from J P Nagar Metro Station, South Bangalore. Vaishnavi Krishna Brindavan Offers Modern & Ultra Luxurious<strong> 3 & 4 BHK Homes</strong> that blend modernity with comfort, aiming to cater to the unique needs and preferences of homeowners. Vaishnavi Krishna Brindavan project spreads around 5 Acres of land scape with 80% open spaces and features close to 362 premium Units. With a G+31 configuration and thoughtfully designed towers, Vaishnavi Krishna Brindavan offers a stunning blend of modern architecture and a serene living environment. Vaishnavi Krishna Brindavan offers well-designed 100% Vaastu Complaint apartments with spacious living, dining, bedroom, balcony, and kitchen spaces. The apartments are well- spaced from each other to maintain privacy and tranquility.</p>

       <p>Vaishnavi Krishna Brindavan offers 50+ world-class amenities including a grand clubhouse with various indoor and outdoor facilities, Gymnasium, Yoga Centre, Pet Park, Swimming Pool, Children’s Play Area, Clubhouse, Garden, Sports Courts, Security, and many more. Residents security is our first priority, so we have implemented 24/7 security measures and the CCTV surveillance systems to ensure a safe & secure environment of our residents. Vaishnavi Krishna Brindavan offers a great & ultra lavish lifestyle where you enjoy luxury, security and community living.</p>

<p>Vaishnavi Group is a highly reputed Real Estate Firm with over 25 years of expertise in Property Development portfolio. The company has 18 Million square feet of residential, commercial and retail projects across Bangalore. The Group has completed 40+ projects with over 6000 happy customers.</p>

<p>J P Nagar, short for Jayaprakash Narayan Nagar, is one of the prominent residential and commercial areas in Bangalore, is known for its well-planned layout, green spaces, and vibrant community life. Situated in the southern part of Bangalore, J P Nagar is strategically located between Bannerghatta Road and Kanakapura Road, two major arterial roads in the city. This location offers easy access to key areas such as Jayanagar, BTM Layout, and Koramangala, making it a preferred choice for both residential and commercial purposes. J P Nagar is primarily a residential neighborhood, characterized by a mix of independent houses, apartment complexes, and gated communities. The area is known for its well-laid-out streets, parks, and tree-lined avenues, providing a serene and green environment amidst the bustling city life of Bangalore. Many parks and playgrounds within J P Nagar attract residents who enjoy outdoor activities and relaxation.        </p>
<!-- <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;">Enquire Now</a><br><br><br> -->
<a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>
      </div>
      
    </div>
  </section>
  <style>
    html {
      scroll-behavior: smooth;
    }
  body {
  margin: 0;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  
}
a {
      color: red;
      text-decoration: none;
      font-weight: bold;
    }

    a:hover {
      color: red;
      text-decoration: underline;
    }

.about-section {
  padding: 60px 20px;
  background-color:rgb(255, 254, 254);
}

.about-container {
  display: flex;
  flex-wrap: wrap;
  max-width: 1200px;
  margin: 0 auto;
  align-items: center;
  gap: 40px;
}

.about-image img {
  max-width: 100%;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.about-content {
  flex: 1;
}

.about-content h2 {
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #333;
  text-align:center;
}

.about-content p {
  font-size: 1.1rem;
  color: #555;
  margin-bottom: 20px;
  line-height: 1.6;
}

.btn {
  display: inline-block;
  background-color: #0056b3;
  color: white;
  padding: 10px 20px;
  
  justify-content: center;
  align-items: center;
  text-decoration: center;
  border-radius: 6px;
  transition: background-color 0.3s ease;
}
.btn {
  
  justify-content: center;
  align-items: center;
  background-color: #0056b3;
  
}

.btn:hover {
  background-color: #0056b3;
}
</style>
                 <!-- about section end -->

                 <!--====== start project config Vaishnavi Group Section ======-->


<style>
  .section {
    width: 100%;
    padding: 50px 20px;
    background-color: rgb(63, 182, 218);
  }

  .section-heading {
    text-align: center;
    font-size: 36px;
    font-weight: bold;
    margin-bottom: 40px;
    color: #333;
  }

  .section-content {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: space-between;
    gap: 30px;
  }

  .left-list {
    flex: 1;
    min-width: 300px;
    max-width: 500px;
  }

  .left-list ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  .left-list li {
    padding: 12px 16px;
    margin-bottom: 10px;
    background-color: #f5f5f5;
    border-radius: 8px;
    font-size: 16px;
    color: #333;
    transition: background-color 0.3s ease, transform 0.2s ease;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .left-list li:hover {
    background-color: #e0e0e0;
    transform: translateX(5px);
    cursor: pointer;
  }

  .left-list li::before {
    content: '•';
    color: #007BFF;
    font-size: 20px;
  }

  .right-image {
    flex: 1;
    min-width: 280px;
    display: flex;
    justify-content: center;
  }

  .right-image img {
    max-width: 100%;
    height: auto;
    max-height: 500px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    object-fit: cover;
    opacity: 1;
    transform: translateX(50px);
    animation: slideInRight 2s ease-out forwards;
  }

  @keyframes slideInRight {
    from {
      opacity: 0;
      transform: translateX(50px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @media (max-width: 768px) {
    .section-content {
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .left-list {
      max-width: 100%;
    }

    .right-image img {
      height: auto;
      max-height: 300px;
      transform: none;
      animation: none;
    }
  }
</style>

<section class="section">
  <h2 class="section-heading">Vaishnavi Krishna Brundavan Price</h2>
  <div class="section-content">
    <div class="left-list">
      <ul>
        <li>Project Type : Apartment</li>
        <li>Unit Type : 3 & 4 BHK</li>
        <li>Project Location : J P Nagar, Bangalore</li>
        <li>Project Area : 5 Acres</li>
        <li>Total Units : 362 Units</li>
        <li>Elevation : G+31 Floors</li>
        <li>Possession Time : Dec, 2027</li>
      </ul>
    </div>
    <div class="right-image">
      <img src="assets/images/imagesv.jpg" alt="Apartment Project View" />
    </div>
  </div>
</section>

<!--====== end project config Vaishnavi Group Section ======-->

<!--====== start price  Vaishnavi Group Section ======-->
<style>
    .block-style-fourteen {
        background-color: white;
        padding: 20px;
        border-radius: 8px;
        transition: background-color 0.3s ease;
    }

    .block-style-fourteen:hover {
        background-color: black;
    }

    .block-style-fourteen .text h1,
    .block-style-fourteen .text h2,
    .block-style-fourteen .text h3,
    .block-style-fourteen .text a {
        transition: color 0.3s ease;
    }

    .block-style-fourteen:hover .text h1,
    .block-style-fourteen:hover .text h2,
    .block-style-fourteen:hover .text h3 {
        color: white !important;
    }

    .block-style-fourteen:hover .text h3 {
        color: red !important;
    }

    .block-style-fourteen:hover .btn-link {
        color:rgb(247, 246, 242) !important; /* gold for visibility, adjust as needed */
    }
</style>

<section class="service-area pb-120" id="price">
    <div class="container">
        <h1 style="color: black; font-size: 32px; font-weight: bold; text-align: center;">Vaishnavi Krishna Brindavan Price</h1>
        <div class="row">
            <div class="col-lg-6 col-md-12" style="color: black;">
                <div class="block-style-fourteen mb-30 d-flex wow fadeInUp" data-wow-delay=".2s">
                    <div class="text">
                        <h1>3 BHK</h1>
                        <h2>Area : Updating Soon...</h2>
                        <h3 style="color: red;">Price : On Request</h3>
                        <!-- <a href="#" class="btn-link">Enquire Now</a> -->
                        <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="block-style-fourteen mb-30 d-flex wow fadeInUp" data-wow-delay=".3s">
                    <div class="text">
                        <h1>4 BHK</h1>
                        <h2>Area : Updating Soon...</h2>
                        <h3 style="color: red;">Price : On Request</h3>
                        <!-- <a href="#" class="btn-link">Enquire Now</a> -->
                        <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== endprice   Vaishnavi Group Section ======-->

<!--====== start flore plane    Vaishnavi Group Section ======-->

<style>
  .section-container {
    text-align: center;
    padding: 40px 20px;
    background-color: rgb(253, 250, 250);
  }

  .section-heading {
    font-size: 32px;
    font-weight: bold;
    margin-bottom: 20px;
  }

  .enquiry-button,
  .btn-link {
    background-color: #007bff;
    color: white;
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    text-decoration: none;
    display: inline-block;
    margin-top: 30px;
  }

  .images-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    max-width: 1000px;
    margin: 0 auto;
  }

  .images-container img {
    width: 100%;
    max-width: 420px;
    border-radius: 12px;
    object-fit: cover;
    
  }

  @media (max-width: 768px) {
    .section-heading {
      font-size: 24px;
    }

    .images-container {
      flex-direction: column;
      align-items: center;
    }

    .images-container img {
      width: 100%;
    }
  }
</style>

<section class="section-container" id="floreplane">
  <h2 class="section-heading">Vaishnavi Krishna Brindavan Floor Plan</h2>

  <div class="images-container">
    <img src="assets/images/Vaishnavflore.jpg" alt="Left Product Image">
    <img src="assets/images/Vaishnavflore.jpg" alt="Right Product Image">
  </div><br><br>

  <!-- <a href="#" class="btn-link">Enquire Now</a> -->
  <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>

</section>



<!--====== end flore plane  Vaishnavi Group Section ======-->


<!--======start Master Plan Vaishnavi Group Section ======-->


<style>
  .section1 {
    padding: 60px 20px;
    text-align: center;
    background-color: #ffffff;
  }

  .section1 h2 {
    font-size: 2.5rem;
    margin-bottom: 20px;
    color: #333;
  }

  .image-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 10px;
  }

  .image-grid img {
    width: 100%;
    max-height: 500px;
    object-fit: cover;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .image-grid img:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
  }

  /* Responsive font size */
  @media (max-width: 768px) {
    .section1 h2 {
      font-size: 2rem;
    }

    .image-grid img {
      max-height: 400px;
    }
  }

  @media (max-width: 480px) {
    .section1 h2 {
      font-size: 1.5rem;
    }

    .image-grid img {
      max-height: 300px;
    }
  }
</style>

<section class="section1">
  <h2>Vaishnavi Krishna Brindavan Master Plan</h2>
  <div class="image-grid">
    <img src="assets/images/mplnimges.jpg" alt="Product 1" />
  </div><br>
  <!-- <a href="#" class="btn-link">Enquire Now</a> -->
  <a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>

</section>



<!--======end Master Plan  Vaishnavi Group Section ======-->


<!--  location section start -->
<style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    .location-section {
      padding: 40px 20px;
      background-color:#5cbbe0;
      text-align: center;
    }

    .location-section h2 {
      font-size: 2em;
      color: #222;
      margin-bottom: 10px;
      text-transform: uppercase;
    }

    .location-section p {
      font-size: 1.1em;
      color: #555;
      margin-bottom: 30px;
    }

    .map-container {
      width: 100%;
      max-width: 1000px;
      height: 400px;
      margin: 0 auto;
      border: 2px solid #ddd;
      border-radius: 10px;
      overflow: hidden;
    }

    iframe {
      width: 100%;
      height: 100%;
      border: 0;
    }
  </style>
  <section class="location-section">
    <h2>Visit Our Location</h2>
    <p>Site Address : J P Nagar, Just 500 M away from J P Nagar Metro Station, South Bangalore</p>
    
    <div class="map-container">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d147997.36006928558!2d77.52863553867665!3d12.902799249637816!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15000078a125%3A0x5d34b732f14a4b2f!2sVaishnavi%20AT-One%20Krishna%20Brindavan!5e0!3m2!1sen!2sus!4v1744727981827!5m2!1sen!2sus" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
  </section><br>
       

         <!--  location section end -->
<!-- about location section start -->
<section class="about-location" id="about-location">
    <div class="about-container">
      
      <div class="about-content">
        <h2>About Location</h2>
        <p>
        
        J P Nagar stands out as a well-rounded neighborhood in Bangalore, combining residential tranquility with commercial vibrancy. Its strategic location, coupled with excellent amenities and a strong community spirit, makes it a preferred choice for many seeking a balanced urban lifestyle in the Silicon Valley of India. J P Nagar is not just about residential and commercial spaces; it also offers a rich cultural experience. The area has community centers, auditoriums, and cultural hubs that host events, concerts, and performances, contributing to its vibrant social life.</P>
       <p>J P Nagar in Bangalore offers a several advantages that make it a highly desirable locality for residents and businesses. Here are some of the key advantages:</p>
<p><strong>Strategic Location :</strong> J P Nagar’s strategic position in South Bangalore provides easy access to major IT hubs, educational institutions, healthcare facilities, and commercial centers. It is situated between Bannerghatta Road and Kanakapura Road, both crucial arteries connecting various parts of the city.</p>
<p><strong>Well-Planned Layout :</strong> The locality is known for its well-organized layout with numbered phases (e.g., JP Nagar Phase 1, Phase 2, etc.), making navigation straightforward and facilitating efficient urban planning. This structured approach contributes to a clean, organized environment that enhances quality of life.</p>
<p><strong>Residential : </strong>J P Nagar offers a diverse range of residential options, including independent houses, apartments, and gated communities. Each phase has its own charm, catering to different preferences and budget ranges. The presence of parks, green spaces, and tree-lined avenues adds to the residential appeal, providing a serene environment amidst the urban hustle.</p>
<p><strong>Amenities and Facilities :</strong> The locality boasts excellent amenities essential for comfortable living. These include reputed schools, colleges, hospitals, supermarkets, shopping malls, restaurants, cafes, and entertainment centers. Residents have easy access to all daily necessities and recreational activities, fostering a convenient lifestyle.</p>
<p><strong>Connectivity :</strong> J P Nagar enjoys exceptional connectivity with well-developed road networks. Bannerghatta Road, Kanakapura Road, and the Outer Ring Road provide quick access to major parts of Bangalore. Additionally, proximity to metro stations (such as Jayanagar and Banashankari) and reliable BMTC bus services ensure efficient public transport options.</p>
<p><strong>Educational Institutions :</strong> There are many renowned educational institutions in and around J P Nagar, which cater to the educational needs of residents from preschool to higher education level. This makes it an ideal locality for families with children, ensuring quality education in the nearby area.</p>
<p><strong>Healthcare Facilities :</strong> The locality is well-equipped with healthcare facilities, including hospitals, clinics, and diagnostic centers. Residents have access to quality medical care, ensuring peace of mind in terms of healthcare services.</p>
<p><strong>Commercial Opportunities :</strong> J P Nagar is also a thriving commercial hub with offices, retail stores, business centers, and IT parks. This mix of residential and commercial spaces creates a dynamic environment that attracts professionals and businesses looking for a strategic location in Bangalore.</p>
<p><strong>Green Spaces and Environment : </strong>J P Nagar maintains its green cover with parks and gardens spread everywhere. These green spaces not only enhance the aesthetic appeal but also promote a healthy environment, which contributes to the overall well-being of residents.</p>
<p>J P Nagar combines strategic location, excellent infrastructure, diverse housing options, quality amenities, and a strong sense of community, making it one of the most sought-after localities in Bangalore for both residential and commercial purposes.</p>
<!-- <a href="#contact" class="btn">Book visit Site</a><br><br><br> -->
<a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>

      </div>
      
    </div>
  </section>
  <style>
    html {
      scroll-behavior: smooth;
    }
  body {
  margin: 0;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  
}
a {
      color: red;
      text-decoration: none;
      font-weight: bold;
    }

    a:hover {
      color: red;
      text-decoration: underline;
    }

.about-section {
  padding: 60px 20px;
  background-color:rgb(255, 254, 254);
}

.about-container {
  display: flex;
  flex-wrap: wrap;
  max-width: 1200px;
  margin: 0 auto;
  align-items: center;
  gap: 40px;
}

.about-image img {
  max-width: 100%;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.about-content {
  flex: 1;
}

.about-content h2 {
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #333;
  text-align:center;
}

.about-content p {
  font-size: 1.1rem;
  color: #555;
  margin-bottom: 20px;
  line-height: 1.6;
}

.btn {
  display: inline-block;
  background-color:red;
  color: white;
  padding: 10px 20px;
  
  justify-content: center;
  align-items: center;
  text-decoration: center;
  border-radius: 6px;
  transition: background-color 0.3s ease;
}
.btn {
  
  justify-content: center;
  align-items: center;
  
}

.btn:hover {
  background-color: #0056b3;
}
</style>
                 <!-- about location section end -->

                  <!--====== start gallarySection ======-->
        <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color:rgb(255, 255, 255);
    }

    .gallery-section {
      text-align: center;
      padding: 60px 20px;
      max-width: 1200px;
      margin: auto;
    }

    .gallery-section h2 {
      font-size: 2.5rem;
      margin-bottom: 10px;
      color: #333;
    }

    .gallery-section p {
      font-size: 1.1rem;
      color: #666;
      margin-bottom: 40px;
    }

    .gallery-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .gallery-grid img {
      width: 100%;
      height: auto;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .gallery-grid img:hover {
      transform: scale(1.05);
    }

    @media (max-width: 600px) {
      .gallery-section h2 {
        font-size: 2rem;
      }

      .gallery-section p {
        font-size: 1rem;
      }
    }
  </style>
   <section class="gallery-section" id= "gallery-section">
    <h2>Amenities</h2>
    <p>Vaishnavi Krishna Brindavan is a ultra luxurious residential apartment project which offers modern amenities like a multi-purpose hall, gym, car parking, swimming pool, clubhouse, Jacuzzi, health club, basketball court, garden, and many more. This project also has the provision of fitness, spa, wide reception, security provision, gated community, internet connectivity, and many more. This project has top class Amenities like Club House, 24Hrs Water Supply, Badminton Court, Basket Ball Court, CCTV Cameras, Covered Car Parking, Fire Safety, Gated Community, Gym, Intercom, Jacuzzi Steam Sauna, Jogging Track, Landscaped Garden, Outdoor games, Party Area, Rain Water Harvesting, Security Personnel, Swimming Pool, Table Tennis, Tennis Court, Visitor Parking, Multipurpose Hall, 24Hrs Backup Electricity for Common Areas and Yoga Deck. Below is the main highlights.</p>
    
    <div class="gallery-grid">
      <img src="assets/images/Gym.jpg" alt="Gallery Image 1">
      <img src="assets/images/Pool-Table.jpg" alt="Gallery Image 2">
      <img src="assets/images/Cycling-Riding.jpg" alt="Gallery Image 3">
      
    </div>
    <br>
    <div class="gallery-grid">
      <img src="assets/images/Kids-Play-Area.jpg" alt="Gallery Image 1">
      <img src="assets/images/Swimming-Pool.jpg" alt="Gallery Image 2">
      <img src="assets/images/Table-Tennis-1024x682.jpg" alt="Gallery Image 3">  
    </div>
  </section>
        <!--====== End gallary Section ======-->

        <!-- connectivity section start -->
 <section class="about-section">
    <div class="about-container">
      
      <div class="about-content">
        <h2>connectivity</h2>
        <p>J P Nagar in Bangalore is well-connected through various modes of transportation, ensuring convenient accessibility within the locality and to other parts of the city. Here’s a detailed overview of its connectivity:</p>
        
        <h5 style="text-decoration-line: underline";>Road Connectivity</h5><br>
<p><strong>1.Bannerghatta Road and Kanakapura Road :</strong> J P Nagar is situated between these two major arterial roads, providing seamless connectivity to key areas like Jayanagar, BTM Layout, Koramangala, and beyond. These roads are lifelines for commuting within Bangalore.</p>
<p><strong>2.Outer Ring Road (ORR) : </strong>The Outer Ring Road is easily accessible from J P Nagar, facilitating connectivity to IT hubs such as Electronic City, Sarjapur Road, and Whitefield. This road also connects to major highways like Hosur Road and Mysore Road.</p>
<p><strong>3.NICE Road :</strong> The Nandi Infrastructure Corridor Enterprise (NICE) Road offers a convenient bypass around Bangalore. It can be accessed from J P Nagar, providing quicker connectivity to the northern and western parts of the city.</p>
<p><strong>Metro Connectivity :</strong> It is well-connected to the metro network via the Green Line (Namma Metro). The nearest metro stations are Jayanagar and Banashankari, both located within a short distance from various parts of J P Nagar.</p>
<h5 style="text-decoration-line: underline";>Public Transport</h5><br>
<p><strong>1.BMTC Bus Services :</strong> Bangalore Metropolitan Transport Corporation (BMTC) operates numerous bus routes through J P Nagar, connecting it to various parts of Bangalore. Bus connectivity is frequent and reliable, catering to the commuting needs of residents.</p>
<p><strong>2.Auto Rickshaws and Taxis :</strong> Auto rickshaws and taxis are readily available throughout J P Nagar, providing convenient transportation options for short distances or specific destinations within and outside the locality.</p>
<h5 style="text-decoration-line: underline";>Future Developments</h5><br>
<p><strong>1.Metro Expansion :</strong> There are plans for further expansion of the metro network in Bangalore, which could potentially bring a metro station closer to J P Nagar in the future, enhancing its connectivity even more.</p>
<p><strong>2.Infrastructure Improvements :</strong> Ongoing infrastructure projects, such as road widening and improvements, aim to alleviate traffic congestion and improve overall connectivity within J P Nagar and its surroundings.</p>
<p>J P Nagar benefits from its strategic location, robust road network, extensive public transport options, and future infrastructure plans, ensuring seamless connectivity and enhancing its appeal as a well-connected neighborhood within Bangalore.</p>
<!-- <a href="#contact" class="btn">Enquire Now</a><br><br><br> -->
<a href="#" class="btn" style="color: #ffffff; background-color: #007bff;" onclick="openModal()">Enquire Now</a>

      </div>
      
    </div>
  </section>
  <style>
    html {
      scroll-behavior: smooth;
    }
  body {
  margin: 0;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  
}
a {
      color: red;
      text-decoration: none;
      font-weight: bold;
    }

    a:hover {
      color: red;
      text-decoration: underline;
    }

.about-section {
  padding: 60px 20px;
  background-color:rgb(255, 254, 254);
}

.about-container {
  display: flex;
  flex-wrap: wrap;
  max-width: 1200px;
  margin: 0 auto;
  align-items: center;
  gap: 40px;
}

.about-image img {
  max-width: 100%;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.about-content {
  flex: 1;
}

.about-content h2 {
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #333;
  text-align:center;
}

.about-content p {
  font-size: 1.1rem;
  color: #555;
  margin-bottom: 20px;
  line-height: 1.6;
}

.btn {
  display: inline-block;
  background-color:red;
  color: white;
  padding: 10px 20px;
  
  justify-content: center;
  align-items: center;
  text-decoration: center;
  border-radius: 6px;
  transition: background-color 0.3s ease;
}
.btn {
  
  justify-content: center;
  align-items: center;
  
}

.btn:hover {
  background-color: #0056b3;
}
</style>
                 <!-- connectivity section end -->

                 <!--====== Start form Section ======-->
<section class="contact-section" id="contact-section">
  <div class="contact-container">
    <div class="contact-images">
      <img src="assets/images/frmimgv.jpg" alt="Contact Image 1">
    </div>

    <form class="contact-form" action="enquire_form.php" method="POST" >
      <h2>Get in Touch with Us</h2>
      <input type="text" name="name" placeholder="Your Name" required>
      <input type="tel" name="mobile" placeholder="Phone Number" required>
      <input type="email" name="email" placeholder="Email" required>
      <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
      <button type="submit">Send Message</button>
    </form>
  </div>
</section>
<style>


.contact-section {
  padding: 40px 20px;
  display: flex;
  justify-content: center;
  background:#5cbbe0;
}

.contact-container {
  display: flex;
  max-width: 1000px;
  width: 100%;
  background: #5cbbe0;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.contact-images {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  background-color: #5cbbe0;
  padding: 20px;
}

.contact-images img {
  width: 100%;
  height: auto;
  border-radius: 8px;
  margin-bottom: 20px;
}

.contact-form {
  flex: 1;
  padding: 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.contact-form h2 {
  margin-bottom: 20px;
  font-size: 35px;
  color: white;
}

.contact-form input,
.contact-form textarea {
  margin-bottom: 8px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 16px;
  width: 100%;
}

.contact-form button {
  padding: 12px;
  border: none;
  background-color: #007BFF;
  color: #fff;
  font-size: 16px;
  border-radius: 8px;
  cursor: pointer;
  
}

.contact-form button:hover {
  background-color: #0056b3;
}

@media (max-width: 768px) {
  .contact-container {
    flex-direction: column;
  }

  .contact-images {
    flex-direction: row;
    gap: 10px;
    overflow-x: scroll;
  }

  .contact-form {
    padding: 20px;
  }
}
</style>
<!--====== Start form end Section ======-->

<!--====== start About Vaishnavi GroupSection ======-->
<section class="about-section">
    <div class="about-container">
      
      <div class="about-content">
        <h2>About Vaishnavi Group</h2>
        <p>In a journey of over 25 years, Vaishnavi Group has notched numerous milestones, with our pioneering efforts delivering immense value to all our stakeholders. Our rich and varied portfolio of residential, commercial and retail projects stand as proud testimony of our capability to create strong, vibrant communities and thriving workspaces.</p>
 
<p>Vaishnavi Group adheres to impeccable standards, and develops projects which are thoughtful, innovative and perfectly positioned across the landscape of the city. This combination not only lends a distinctive appeal to the properties, but enables us to exceed the expectations of our customers across categories. Ultimately, to us the way forward is what it always has been – to build from the heart.</p>
<p>At Vaishnavi Group, we are highly focused in developing niche and urban-centric real estate properties across residential and commercial property segments. We take great pride and care in delivering exquisite designs, best in class amenities and feature-rich dwellings. Our objective is to make our residents fall in love with the structures and the facilities that comes along with it.</p>
      </div>
      
    </div>
  </section>
  <style>
    html {
      scroll-behavior: smooth;
    }
  body {
  margin: 0;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  
}
a {
      color: red;
      text-decoration: none;
      font-weight: bold;
    }

    a:hover {
      color: red;
      text-decoration: underline;
    }

.about-section {
  padding: 60px 20px;
  background-color:rgb(255, 254, 254);
}

.about-container {
  display: flex;
  flex-wrap: wrap;
  max-width: 1200px;
  margin: 0 auto;
  align-items: center;
  gap: 40px;
}

.about-image img {
  max-width: 100%;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.about-content {
  flex: 1;
}

.about-content h2 {
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #333;
  text-align:center;
}

.about-content p {
  font-size: 1.1rem;
  color: #555;
  margin-bottom: 20px;
  line-height: 1.6;
}

.btn {
  display: inline-block;
  background-color:red;
  color: white;
  padding: 10px 20px;
  
  justify-content: center;
  align-items: center;
  text-decoration: center;
  border-radius: 6px;
  transition: background-color 0.3s ease;
}
.btn {
  
  justify-content: center;
  align-items: center;
  
}

.btn:hover {
  background-color: #0056b3;
}
</style>
<!--====== end About Vaishnavi Group Section ======-->


                  
        <!--====== Start faq Section ======-->
<style>
   
   .faq-section {
     max-width: 1400px;
     margin: auto;
     width: 100%;
     background-color: #5cbbe0;
     padding: 50px 20px;
   }

   .faq-section h2 {
     text-align: center;
     margin-bottom: 30px;
     font-size: 2.5rem;
     color: #333;
   }

   details {
     background: white;
     border-radius: 12px;
     box-shadow: 0 4px 8px rgba(0,0,0,0.05);
     margin-bottom: 15px;
     overflow: hidden;
     transition: box-shadow 0.3s ease;
   }

   details[open] {
     box-shadow: 0 6px 16px rgba(0,0,0,0.1);
   }

   summary {
     padding: 20px;
     cursor: pointer;
     font-size: 1.2rem;
     font-weight: 600;
     color: #222;
     position: relative;
   }

   summary::marker {
     display: none;
   }

   summary::after {
     content: '+';
     position: absolute;
     right: 20px;
     font-size: 1.5rem;
     transition: transform 0.3s ease;
   }

   details[open] summary::after {
     content: '−';
     transform: rotate(180deg);
   }

   .faq-content {
     padding: 0 20px 20px 20px;
     font-size: 1rem;
     line-height: 1.6;
     color: #555;
     animation: fadeIn 0.3s ease-in-out;
   }

   @keyframes fadeIn {
     from {
       opacity: 0;
       transform: translateY(-5px);
     }
     to {
       opacity: 1;
       transform: translateY(0);
     }
   }

   @media (max-width: 600px) {
     .faq-section h2 {
       font-size: 2rem;
     }

     summary {
       font-size: 1rem;
     }
     

     .faq-content {
       font-size: 0.95rem;
     }
     

    
    
   }
   </style>
   <style>
   .faq-form {
      background: #fff;
      padding: 20px 30px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      width: cover;
      justify-content: center;
      align-items: center;
      
    }

    .faq-form h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    .faq-form label {
      display: block;
      margin: 10px 0 5px;
      font-weight: bold;
    }

    .faq-form input[type="text"],
    .faq-form input[type="tel"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
    }

    .faq-form button {
      width: 100%;
      margin-top: 15px;
      padding: 10px;
      background-color:rgb(102, 212, 240);
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 16px;
    }

    .faq-form button:hover {
      background-color:rgb(79, 209, 241);
    }
    </style>
<section class="faq-section">
   <h2>Frequently Asked Questions</h2>

   <details>
     <summary>Whrere is vaishnavi krishna brundavana located?</summary>
     <div class="faq-content">
     Vaishnavi Krishna Brindavan is located in J P Nagar, Just 500 M away from J P Nagar Metro Station, South Bangalore.     </div>
   </details>

   <details>
     <summary>what kind of development is it?</summary>
     <div class="faq-content">
     Vaishnavi Krishna Brindavan is a ultra luxurious apartment project.
     </div>
   </details>

   <details>
     <summary>What are the defferent varients of apartment it offers?</summary>
     <div class="faq-content">
     Vaishnavi Krishna Brindavan project offers 3BHK & 4BHK Ultra Luxurious Apartment Homes.     </div>
   </details>

   <details>
     <summary>How do i book my flat at vaishnavi krishna brundavana project?</summary>
     <div class="faq-content">
     Reach us by filling in the contact form below to get complete assistance in booking:    </div>
     <form class="faq-form">
    
    <label for="name">Name</label>
    <input type="text" id="name" name="name" required>
    
    <label for="mobile">Mobile Number</label>
    <input type="tel" id="mobile" name="mobile" pattern="[0-9]{10}" required>
    
    <button type="submit">Submit</button>
  </form>
   </details>

   <details>
     <summary>What is the total project area?</summary>
     <div class="faq-content">
     Vaishnavi Krishna Brindavan total project area is 5 acres.     </div>
   </details>

   <details>
     <summary>Can vaishnavi krishna brundavana project be reached by the metro station?</summary>
     <div class="faq-content">
     Yes, The metro stations at JP Nagar, JP Nagar 4th Phase, and Yelachenahalli are close to Vaishnavi Krishna Brindavan.    </div>
   </details>

   <details>
     <summary>What do if have more questions or need furthur clarification?</summary>
     <div class="faq-content">
      Reach us by filling in the contact form below, so that we can reach you at the earliest to clarify all your queries:  </div>
      <form class="faq-form">
    
    <label for="name">Name</label>
    <input type="text" id="name" name="name" required>
    
    <label for="mobile">Mobile Number</label>
    <input type="tel" id="mobile" name="mobile" pattern="[0-9]{10}" required>
    
    <button type="submit">Submit</button>
  </form>
    </details>
 </section>

<!--====== end faq Section ======-->
<!--====== start declaimer  Section ======-->

  <style>
    .disclaimer-section {
      background-color: #f9f9f9;
      color: #333;
      font-size: 17px;
      padding: 30px;
      line-height: 1.6;
      border-top: 1px solid #ddd;
    }

    .disclaimer-section h3 {
      margin-top: 0;
      font-size: 16px;
      font-weight: 600;
      color: #222;
    }

    @media (max-width: 600px) {
      .disclaimer-section {
        font-size: 13px;
        padding: 15px;
      }
    }
  </style>


  <section class="disclaimer-section">
    
    <p>
    <strong>Disclaimer:</strong> The content is for information purposes only and does not constitute an offer to avail of any service.
      Prices mentioned are subject to change without notice and properties mentioned are subject to availability.
      Images are for representation purposes only.
    
      This is the official website of the authorized marketing partner. We may share data with RERA registered brokers/companies for further processing.
      We may also send updates to the mobile number/email ID registered with us.<strong>All Rights Reserved.</strong>
    </p>
    
  </section>



<!--====== end declaimer  Section ======-->
       
         <!--====== start floating  Section ======-->
         <!-- Floating Contact Icons -->
<!-- Floating WhatsApp and Back to Top -->
<!-- Floating Contact Icons -->
<!-- Floating WhatsApp and Back to Top -->
<!-- <div class="floating-icons">
  <a href="https://wa.me/1234567890" target="_blank" class="whatsapp-float" title="Chat on WhatsApp">
    <img src="https://img.icons8.com/color/48/000000/whatsapp--v1.png" alt="WhatsApp">
    <span class="phone-number">+1 234 567 890</span>
  </a>

  <button id="backToTop" title="Go to top">↑</button>
</div> -->



<style>

/* Floating Container */
.floating-icons {
  position: fixed;
  bottom: 90px;
  right: 20px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 10px;
}

/* WhatsApp Button */
.whatsapp-float {
  display: flex;
  align-items: center;
  background-color: #25D366;
  color: white;
  padding: 10px 12px;
  border-radius: 30px;
  text-decoration: none;
  font-weight: 500;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s;
}
.whatsapp-float:hover {
  transform: scale(1.05);
}
.whatsapp-float img {
  margin-right: 8px;
  width: 24px;
  height: 24px;
}
.phone-number {
  display: none;
}

@media (min-width: 500px) {
  .phone-number {
    display: inline;
  }
}

/* Back to Top Button */
#backToTop {
  background-color: #333;
  color: white;
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  font-size: 18px;
  cursor: pointer;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  transition: background-color 0.3s, transform 0.3s;
}
#backToTop:hover {
  background-color: #555;
  transform: scale(1.1);
}

</style>

         <!--====== end floating Section ======-->


<!--====== Search From ======-->
<div class="modal fade" id="search-modal">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form>
                <div class="form_group">
                    <input type="text" class="form_control" placeholder="Search here...">
                    <button class="search_btn"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
    </div>
</div><!--====== Search From ======--><a href="#" class="back-to-top" ><i class="far fa-angle-up" style="color:rgb(249, 249, 250);"></i></a><!--====== Jquery js ======-->
<script src="assets/vendor/jquery-3.7.1.min.js"></script>
<!--====== Bootstrap js ======-->
<script src="assets/vendor/popper/popper.min.js"></script>
<!--====== Bootstrap js ======-->
<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--====== Slick js ======-->
<script src="assets/vendor/slick/slick.min.js"></script>
<!--====== Magnific js ======-->
<script src="assets/vendor/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
<!--====== Isotope js ======-->
<script src="assets/vendor/isotope.min.js"></script>
<!--====== Imagesloaded js ======-->
<script src="assets/vendor/imagesloaded.min.js"></script>
<!--====== Counterup js ======-->
<script src="assets/vendor/jquery.counterup.min.js"></script>
<!--====== Waypoints js ======-->
<script src="assets/vendor/jquery.waypoints.js"></script>
<!--====== Number js ======-->
<script src="assets/vendor/jquery.nice-number.min.js"></script>
<!--====== Nice-select js ======-->
<script src="assets/vendor/nice-select/js/jquery.nice-select.min.js"></script>
<!--====== jquery UI js ======-->
<script src="assets/vendor/jquery-ui/jquery-ui.min.js"></script>
<!--====== Donutty js ======-->
<script src="assets/vendor/donutty-jquery.min.js"></script>
<!--====== WOW js ======-->
<script src="assets/vendor/wow.min.js"></script>
<!--====== Main js ======-->
<script src="assets/js/theme.js"></script></body>



</html>      